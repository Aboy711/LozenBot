async function sendMessage() {
  const inputField = document.getElementById('userInput');
  const userText = inputField.value.trim();
  if (!userText) return;

  const chatBox = document.getElementById('chat');
  chatBox.innerHTML += `<p><strong>You:</strong> ${userText}</p>`;
  inputField.value = "";

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer YOUR_API_KEY_HERE"
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: userText }]
    })
  });

  const data = await response.json();
  const botReply = data.choices[0].message.content;
  chatBox.innerHTML += `<p><strong>LozenBot:</strong> ${botReply}</p>`;
  chatBox.scrollTop = chatBox.scrollHeight;
}
